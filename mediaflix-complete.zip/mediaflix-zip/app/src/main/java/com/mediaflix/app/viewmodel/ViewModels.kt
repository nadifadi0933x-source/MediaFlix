package com.mediaflix.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediaflix.app.data.model.MediaItem
import com.mediaflix.app.data.model.MediaType
import com.mediaflix.app.data.repository.MediaRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: MediaRepository
) : ViewModel() {

    private val _trending = MutableStateFlow<List<MediaItem>>(emptyList())
    val trending: StateFlow<List<MediaItem>> = _trending

    private val _popularMovies = MutableStateFlow<List<MediaItem>>(emptyList())
    val popularMovies: StateFlow<List<MediaItem>> = _popularMovies

    private val _popularSeries = MutableStateFlow<List<MediaItem>>(emptyList())
    val popularSeries: StateFlow<List<MediaItem>> = _popularSeries

    private val _trendingAnime = MutableStateFlow<List<MediaItem>>(emptyList())
    val trendingAnime: StateFlow<List<MediaItem>> = _trendingAnime

    private val _popularManhwa = MutableStateFlow<List<MediaItem>>(emptyList())
    val popularManhwa: StateFlow<List<MediaItem>> = _popularManhwa

    private val _currentSeasonAnime = MutableStateFlow<List<MediaItem>>(emptyList())
    val currentSeasonAnime: StateFlow<List<MediaItem>> = _currentSeasonAnime

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init {
        loadAll()
    }

    fun loadAll() {
        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null
            try {
                launch { _trending.value = repository.getTrending() }
                launch { _popularMovies.value = repository.getPopularMovies() }
                launch { _popularSeries.value = repository.getPopularSeries() }
                launch { _trendingAnime.value = repository.getTrendingAnime() }
                launch { _currentSeasonAnime.value = repository.getCurrentSeasonAnime() }
                launch { _popularManhwa.value = repository.getPopularManhwaAniList() }
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _isLoading.value = false
            }
        }
    }
}

@HiltViewModel
class MoviesViewModel @Inject constructor(
    private val repository: MediaRepository
) : ViewModel() {

    private val _movies = MutableStateFlow<List<MediaItem>>(emptyList())
    val movies: StateFlow<List<MediaItem>> = _movies

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private var currentPage = 1

    init {
        loadMovies()
    }

    fun loadMovies() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                _movies.value = repository.getPopularMovies(currentPage)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadMore() {
        viewModelScope.launch {
            currentPage++
            try {
                val more = repository.getPopularMovies(currentPage)
                _movies.value = _movies.value + more
            } catch (e: Exception) {
                currentPage--
            }
        }
    }
}

@HiltViewModel
class SeriesViewModel @Inject constructor(
    private val repository: MediaRepository
) : ViewModel() {

    private val _series = MutableStateFlow<List<MediaItem>>(emptyList())
    val series: StateFlow<List<MediaItem>> = _series

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private var currentPage = 1

    init {
        loadSeries()
    }

    fun loadSeries() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                _series.value = repository.getPopularSeries(currentPage)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadMore() {
        viewModelScope.launch {
            currentPage++
            try {
                val more = repository.getPopularSeries(currentPage)
                _series.value = _series.value + more
            } catch (e: Exception) {
                currentPage--
            }
        }
    }
}

@HiltViewModel
class AnimeViewModel @Inject constructor(
    private val repository: MediaRepository
) : ViewModel() {

    private val _anime = MutableStateFlow<List<MediaItem>>(emptyList())
    val anime: StateFlow<List<MediaItem>> = _anime

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private var currentPage = 1

    init {
        loadAnime()
    }

    fun loadAnime() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val jikan = repository.getTopAnime(currentPage)
                _anime.value = jikan
            } catch (e: Exception) {
                try {
                    _anime.value = repository.getTrendingAnime(currentPage)
                } catch (_: Exception) {}
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadMore() {
        viewModelScope.launch {
            currentPage++
            try {
                val more = repository.getTopAnime(currentPage)
                _anime.value = _anime.value + more
            } catch (e: Exception) {
                currentPage--
            }
        }
    }
}

@HiltViewModel
class MangaViewModel @Inject constructor(
    private val repository: MediaRepository
) : ViewModel() {

    private val _manga = MutableStateFlow<List<MediaItem>>(emptyList())
    val manga: StateFlow<List<MediaItem>> = _manga

    private val _manhwa = MutableStateFlow<List<MediaItem>>(emptyList())
    val manhwa: StateFlow<List<MediaItem>> = _manhwa

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private var mangaPage = 1
    private var manhwaPage = 1

    init {
        loadBoth()
    }

    fun loadBoth() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                launch {
                    _manga.value = repository.getTopManga(mangaPage)
                }
                launch {
                    _manhwa.value = repository.getPopularManhwaAniList(manhwaPage)
                }
            } catch (_: Exception) {} finally {
                _isLoading.value = false
            }
        }
    }

    fun loadMoreManga() {
        viewModelScope.launch {
            mangaPage++
            try {
                val more = repository.getTopManga(mangaPage)
                _manga.value = _manga.value + more
            } catch (e: Exception) {
                mangaPage--
            }
        }
    }

    fun loadMoreManhwa() {
        viewModelScope.launch {
            manhwaPage++
            try {
                val more = repository.getPopularManhwaAniList(manhwaPage)
                _manhwa.value = _manhwa.value + more
            } catch (e: Exception) {
                manhwaPage--
            }
        }
    }
}

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val repository: MediaRepository
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    private val _results = MutableStateFlow<List<MediaItem>>(emptyList())
    val results: StateFlow<List<MediaItem>> = _results

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching

    fun onQueryChange(newQuery: String) {
        _query.value = newQuery
        if (newQuery.length >= 2) {
            search(newQuery)
        }
    }

    private fun search(query: String) {
        viewModelScope.launch {
            _isSearching.value = true
            try {
                _results.value = repository.searchAll(query)
            } catch (_: Exception) {} finally {
                _isSearching.value = false
            }
        }
    }
}

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val repository: MediaRepository
) : ViewModel() {

    private val _details = MutableStateFlow<MediaItem?>(null)
    val details: StateFlow<MediaItem?> = _details

    private val _streamUrl = MutableStateFlow<String?>(null)
    val streamUrl: StateFlow<String?> = _streamUrl

    private val _pdfUrl = MutableStateFlow<String?>(null)
    val pdfUrl: StateFlow<String?> = _pdfUrl

    private val _isBookmarked = MutableStateFlow(false)
    val isBookmarked: StateFlow<Boolean> = _isBookmarked

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    fun loadDetails(id: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                _isBookmarked.value = repository.isBookmarked(id)
                val link = repository.getCustomLink(id)
                _streamUrl.value = link?.streamUrl
                _pdfUrl.value = link?.pdfUrl

                val source = id.substringBefore("_")
                val remoteId = id.substringAfter("_")

                val item = when (source) {
                    "tmdb" -> {
                        val numId = remoteId.toLong()
                        if (id.contains("series")) repository.getSeriesDetail(numId)
                        else repository.getMovieDetail(numId)
                    }
                    "jikan" -> repository.getAnimeDetail(remoteId.toLong())
                    "mangadex" -> repository.getMangaDexDetail(remoteId)
                    else -> null
                }
                _details.value = item
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun toggleBookmark() {
        viewModelScope.launch {
            _details.value?.let { item ->
                repository.toggleBookmark(item)
                _isBookmarked.value = !_isBookmarked.value
            }
        }
    }

    fun setStreamUrl(url: String) {
        viewModelScope.launch {
            _details.value?.let { item ->
                repository.setStreamUrl(item.id, url)
                _streamUrl.value = url
            }
        }
    }

    fun setPdfUrl(url: String) {
        viewModelScope.launch {
            _details.value?.let { item ->
                repository.setPdfUrl(item.id, url)
                _pdfUrl.value = url
            }
        }
    }
}
