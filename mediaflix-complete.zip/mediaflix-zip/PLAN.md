# MediaFlix — Android Media Streaming App

## 🎯 هدف پروژه
یک اپلیکیشن اندروید با Jetpack Compose برای تماشای آنلاین فیلم، سریال، انیمه، مانگا و مانهوا با استفاده از APIهای رایگان عمومی و لینک‌های استریم/PDF که توسط ادمین مدیریت می‌شوند.

## 🔌 APIهای رایگان استفاده شده

| API | کاربرد | نوع احراز | نوع Query |
|-----|--------|-----------|-----------|
| **TMDB v3** | فیلم و سریال — پوستر، اطلاعات، trending | API Key (رایگان) | REST |
| **Jikan v4** | انیمه و مانگا — اطلاعات کامل از MyAnimeList | بدون کلید | REST |
| **AniList** | انیمه و مانگا — کوئری‌های پیشرفته | بدون کلید (عمومی) | GraphQL |
| **MangaDex** | مانگا — چپترها و ترجمه‌ها | بدون کلید | REST |
| **ShineiAPI** | مانهوا و مانگا — جستجو و اطلاعات | بدون کلید | REST |

## 🏗 معماری

- **MVVM + Clean Architecture**
- **Jetpack Compose** برای UI
- **Hilt** برای Dependency Injection
- **Retrofit + OkHttp** برای network calls
- **Room Database** برای ذخیره‌سازی محلی (نشان‌ها، لینک‌های سفارشی)
- **ExoPlayer** برای پخش ویدیو
- **AndroidPdfViewer** برای نمایش PDF
- **Coil** برای لود تصاویر
- **Kotlin Coroutines + Flow**

## 📱 Screen Flow

```
MainActivity
├── BottomNavigation
│   ├── HomeScreen (پیشنهادی‌ها، trending)
│   ├── MoviesScreen (فیلم‌ها)
│   ├── SeriesScreen (سریال‌ها)
│   ├── AnimeScreen (انیمه‌ها)
│   ├── MangaScreen (مانگا/مانهوا)
│   └── SearchScreen (جستجو)
├── DetailScreen (جزئیات فیلم/انیمه/مانگا)
├── PlayerScreen (پخش ویدیو با ExoPlayer)
├── PdfReaderScreen (نمایش PDF مانگا/مانهوا)
└── SettingsScreen (مدیریت API keyها و لینک‌های سفارشی)
```

## 🔗 مدیریت لینک‌های استریم و PDF

ادمین می‌تواند از طریق پنل Settings:
- به هر عنوان یک **لینک استریم مستقیم** (MP4, M3U8, MKV) اضافه کند
- به هر مانگا/مانهوا یک **لینک PDF** اضافه کند
- این لینک‌ها در Room Database ذخیره می‌شوند

## 📊 Data Flow

```
API (TMDB/Jikan/AniList/MangaDex/ShineiAPI)
    ↓
Retrofit Service → Repository → ViewModel → Compose UI
                                    ↑
                            Room Database (local links & bookmarks)
```
